class Solution:
    def calculate(self, s: int) -> int:
        