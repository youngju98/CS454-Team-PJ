class Solution:
    def calculate(self, s: str) -> int:
        
        