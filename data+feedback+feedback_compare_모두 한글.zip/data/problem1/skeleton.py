class Solution:
    def calculate(self, s: str) -> str:
        